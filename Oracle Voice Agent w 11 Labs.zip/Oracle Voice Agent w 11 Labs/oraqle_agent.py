import speech_recognition as sr
from elevenlabs.client import ElevenLabs
from elevenlabs import play
from grokapi import Grok  # Or use openai if you prefer
import tempfile

# Your keys (swap these!)
ELEVENLABS_KEY = "sk_5d794b9f1b968de005a036c5d9c51375f76801be46694928"
GROK_KEY = "YOUR_GROK_API_KEY"  # From x.ai/api

# Setup
client = ElevenLabs(api_key=ELEVENLABS_KEY)
grok = Grok(api_key=GROK_KEY)
r = sr.Recognizer()

def listen():
    with sr.Microphone() as source:
        print("Listening... Say 'Hey ORAQLE' to wake up.")
        audio = r.listen(source, timeout=5)
    try:
        text = r.recognize_whisper(audio, model="base")
        print(f"You said: {text}")
        return text.lower()
    except:
        return None

def think(text):
    prompt = f"You are ORAQLE, a helpful AI assistant. Respond concisely and funnily to: {text}"
    response = grok.chat.completions.create(
        messages=[{"role": "user", "content": prompt}],
        model="grok-beta"
    )
    return response.choices[0].message.content

def speak(text):
    audio = client.text_to_speech.convert(
        text=text,
        voice_id="21m00Tcm4TlvDq8ikWAM",  # Rachel
        model_id="eleven_multilingual_v2"
    )
    play(audio)

# Main Loop
print("ORAQLE Agent ready! Say 'Hey ORAQLE' to start.")
while True:
    user_input = listen()
    if user_input and "hey oraqle" in user_input:
        query = user_input.replace("hey oraqle", "").strip()
        if query:
            response = think(query)
            print(f"ORAQLE: {response}")
            speak(response)
        else:
            speak("What can I do for you?")
    elif user_input:
        speak("Say 'Hey ORAQLE' to wake me up!")